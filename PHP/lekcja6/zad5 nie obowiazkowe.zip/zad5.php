<!DOCTYPE HTML>
<html lang="pl">
<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>Wysyłanie danych na serwer WWW poprzez formularz</title>  
</head>
<body>

 <form action="" method="post">
      godzine<input type="text" name="l1" />
      <input type="submit" name="wynik" value="Oblicz" />
    </form>
	
	

  
	
	<?php
	include "zad5_pomoc.php";
	
	if(isset($_POST['wynik']))
	{

	
	$godzina=$_POST['l1'];
	
	$tab[]= Array('godzina 8 śniadanie', 'godz. 9-10 wykład', 'godz 11-13 zajęcia w grupach', 'godz 14 obiad', 'godz 15-17 film', 'godz. 18-19 kolacja');
	
	zadb($tab[],$godzina);

	
	
	
	
	
	
	}
	
?>
</body>
</html>
