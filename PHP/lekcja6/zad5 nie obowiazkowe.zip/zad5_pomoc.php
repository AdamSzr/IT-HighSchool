	<?php
	function zadb($tab,$czas)
	{
		$licz=0;
		if ($czas==8)
		{
			for ($licz;$licz<6;$licz++)
			echo $tab[$licz];
		}
		else if($czas>=9 && $czas<=10)
		{
			$licz=1;
				for ($licz;$licz<6;$licz++)
				{
				echo $tab[$licz];
				}
		}
		else if($czas>=11 && $czas<=13)
		{
				$licz=2;
				for ($licz;$licz<6;$licz++)
				{
				echo $tab[$licz];
				}
		}
			
		else if($czas==14)
		{
			$licz=3;
			for ($licz;$licz<6;$licz++)
			{
			echo $tab[$licz];
			}
		}
		
		else if($czas>=15 && $czas<=17)
		{
		$licz=4;
			for ($licz;$licz<6;$licz++)
			{
			echo $tab[$licz];
			}
		}
		else if($czas>=18 && $czas<=19)
		{
			$licz=5;
			for ($licz;$licz<6;$licz++)
			{
			echo $tab[$licz];
			}
		}
		
		else 
		{
		echo "wpisano niepoprawne dane";
		}
		
	{
	
	?>